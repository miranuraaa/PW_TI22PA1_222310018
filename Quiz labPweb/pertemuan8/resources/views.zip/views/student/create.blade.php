@extends('layout/main')
@section('title','Detail Mahasiswa')

@section('container')
<div class="row">
<div class="col-4" style="margin-left:10px">
    <h3>Tambah Data</h3>
    <form method="post" action="/student">
        @csrf
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="fullnama" class="form-control" placeholder="Enter Full Name">
          <!--<div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>-->
        </div>

        <div class="mb-3">
            <label class="form-label">NPM</label>
            <input type="text" name="npm" class="form-control" placeholder="Enter NPM">
            <!--<div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>-->
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" placeholder="Ketik Email">
            <!--<div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>-->
          </div>

          <div class="mb-3">
            <label class="form-label">Prodi</label>
            <input type="text" name="prodi" class="form-control" placeholder="Enter Prodi">
            <!--<div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>-->
          </div>

        <button type="submit" class="btn btn-primary">Tambah Data</button>
    </form>
</div>
</div>

@endsection
